package sinalgo.models.EnergyModel.simple;


import java.util.Hashtable;
import java.util.Iterator;

import projects.DAARPMSWIM.nodes.nodeImplementations.DAARPMSWIMNode;
import projects.DDAARP.nodes.nodeImplementations.DDAARPNode;
import projects.GA.nodes.nodeImplementations.GANode;
import projects.Infra.nodes.nodeImplementations.InfraNode;
import projects.SPT.nodes.nodeImplementations.SPTNode;
import sinalgo.models.EnergyModel.IEnergy;
import sinalgo.models.EnergyModel.EnergyMode;
import sinalgo.nodes.Node;
import sinalgo.tools.Tools;


public class SimpleEnergy implements IEnergy {
    
    private Float sleep;
    private Float transmission;
    private Float receive;
    private Float processing;
    private Float listen;
    private Float totalEnergy;
    
    private int nodeID;		//1-indexed
    private boolean isSinkNeighbor = false;	//Used for the energy hole metric
   
    private Hashtable<Double, Float> energyPerRound = new Hashtable<Double, Float>();
   
    public Hashtable<Double, Float> getEnergyPerRound(){
            return energyPerRound;
    }
   
    public SimpleEnergy (int nodeID){
            this.sleep = Float.valueOf(0);
            this.transmission = Float.valueOf(0);
            this.receive = Float.valueOf(0);
            this.processing = Float.valueOf(0);
            this.listen = Float.valueOf(0);
            //this.totalEnergy = 29160f;
            this.totalEnergy = 200f;
            this.nodeID = nodeID;
    }
   
    public void setIsSinkNeighbor(boolean isSinkNeighbor){
    	this.isSinkNeighbor = isSinkNeighbor;
    }
    
    public Float getTotalSpentEnergy(){
            return sleep + transmission + receive + processing + listen;
    }
   
    private void calculateEnergyPerRound(Float value){
            Double round = Tools.getGlobalTime();
            if (energyPerRound.containsKey(round)){
                    Float tmp = energyPerRound.get(round);
                    energyPerRound.put(round, tmp + value);
            }else{
                    energyPerRound.put(round, value);
            }
    }
   
    public void spend(EnergyMode mode, float time){
            switch (mode) {
            case LISTEN:
                    listen += Config.ENERG_ESCUTA;
                    calculateEnergyPerRound(Config.ENERG_ESCUTA);
                    break;
            case RECEIVE:
                    receive += Config.ENERG_RECEPCAO*time;
                    calculateEnergyPerRound(Config.ENERG_RECEPCAO*time);
                    break;
            case SEND:
                    transmission += Config.ENERG_TRANSMISSAO*time;
                    calculateEnergyPerRound(Config.ENERG_TRANSMISSAO*time);
                    break;
            case SLEEP:
                    sleep += Config.ENERG_SLEEP;
                    calculateEnergyPerRound(Config.ENERG_SLEEP);
                    break;
            case PROCESSING:
                    processing += 0;
                    calculateEnergyPerRound(0f);
                    break;
            case MONITOR:                  
                    break;
            default:
                    break;
            }              
    }

    public Float getEnergy() {
            return totalEnergy - getTotalSpentEnergy();
    }
   
    public Float getInitialEnergy(){
            return this.totalEnergy;
    }

	@Override
	public void spend(EnergyMode mode) {
		//The energy model assumes that the energy required for transmission and reception are the same
		spend(mode, 1);
		//if (getEnergy()<0 ){
		if ( getEnergy()<0 && this.nodeID!=1 && this.isSinkNeighbor ){ //Validates if there is no more energy in the neigbors of the sink
			if ( GANode.terminals.contains(this.nodeID-1) ){
				System.out.println("ENERGY LOG: first dead node is " + this.nodeID + " (terminal) at " + Tools.getGlobalTime() + " seconds at round " + this.energyPerRound.size());
			}else{
				System.out.println("ENERGY LOG: first dead node is " + this.nodeID + " at " + Tools.getGlobalTime() + " seconds at round " + this.energyPerRound.size());
			}
			//FIXME: not reporting data into the log because it is not generating the MSGTREE message necessary for collecting the final routing tree.
			
			Iterator<Node> it = Tools.getNodeList().iterator();
			Node next;
			while(it.hasNext()){
				
				next = it.next();
				
				if (next instanceof SPTNode){
					SPTNode.Energy.logln(
						next.ID+"\t"+
						next.getPosition().xCoord+"\t"
						+next.getPosition().yCoord+"\t"
						+((SPTNode)next).getBateria().getEnergy()
					);
				} else if (next instanceof GANode){
					GANode.Energy.logln(
						next.ID+"\t"+
						next.getPosition().xCoord+"\t"
						+next.getPosition().yCoord+"\t"
						+((GANode)next).getBattery().getEnergy()
					);
				} else if (next instanceof InfraNode){
					InfraNode.EnergyNetwork.logln(
							next.ID+"\t"+
							next.getPosition().xCoord+"\t"
							+next.getPosition().yCoord+"\t"
							+((InfraNode)next).getBateria().getEnergy()
					);
				} else if (next instanceof DAARPMSWIMNode){
					DAARPMSWIMNode.DAARPEnergy.logln(
							next.ID+"\t"+
							next.getPosition().xCoord+"\t"
							+next.getPosition().yCoord+"\t"
							+((DAARPMSWIMNode)next).getBattery().getEnergy()
					);
				} else if (next instanceof DDAARPNode){
					;//TODO
				}
			}
			
			sinalgo.tools.Tools.exit();
		}
		//System.out.println("ENERGY LOG: residual energy " + getEnergy() + " for node " + this.nodeID);
		
		
		
	}

    
    
}

