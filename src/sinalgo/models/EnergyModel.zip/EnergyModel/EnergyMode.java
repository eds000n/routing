package sinalgo.models.EnergyModel;

public enum EnergyMode {
	SEND, RECEIVE, SLEEP, LISTEN, MONITOR, PROCESSING
}
